#ifndef _MAIN_C_
#define _MAIN_C_
#include "config.h"
/**
	*	@file:Main.c
	* @brief:������
	* @author:XZ
	* @version:1.0
	* @date:2025/10/20
*/
//��������
void GPIO_Configuration(void);
volatile uint8_t num;
uint32_t numdata;
/**
	* @brief:��ʱ����
	* @param:��ʱʱ��
	* @return:��
*/
void Delay(uint32_t nCount)
{
  for(; nCount != 0; nCount--);
}
/**
	* @brief:������
	* @param:��
	* @return:����
*/
int main(void)
{  
		OLED_TypeDef  OLED_Struct;
		OLED_InitTypeDef OLED_InitStruct;
		OLED_InitStruct.i2c_write_cb = My_SI2C_WriteByte;

		I2C_GPIO_Init();
		OLED_Init(&OLED_Struct,&OLED_InitStruct);
		numdata=10;
		//#1.��ӡHELLO WORLD
		OLED_SetPen(&OLED_Struct,PEN_COLOR_WHITE,1);
		OLED_SetBrush(&OLED_Struct,PEN_COLOR_TRANSPARENT);
		OLED_SetCursor(&OLED_Struct,24,50);
		OLED_DrawString(&OLED_Struct,"HELLO,WORLD");
		// #2.��ʽ�����
		OLED_SetFont(&OLED_Struct,&default_font);
		OLED_SetCursor(&OLED_Struct,58,64);
		OLED_Printf(&OLED_Struct,"%04/%02/%02",2025,10,22);
		OLED_SendBuffer(&OLED_Struct);
		while(1);
}

//=============================================================================
//�ļ����ƣ�GPIO_Configuration
//���ܸ�Ҫ��GPIO��ʼ��
//����˵������
//�������أ���
//=============================================================================
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC , ENABLE); 						 
//=============================================================================
//LED -> PC13
//=============================================================================			 
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
  GPIO_Init(GPIOC, &GPIO_InitStructure);
}
#endif


