#ifndef CONFIG_H
#define CONFIG_H
//ͷ�ļ�
#include "stm32f10x.h"
#include "GPIOLIKE51.h"
#include "IIC.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include "oled.h"

#ifdef _MAIN_C_
#include "oled_default_font.h"
#endif

#include <math.h>
#endif
