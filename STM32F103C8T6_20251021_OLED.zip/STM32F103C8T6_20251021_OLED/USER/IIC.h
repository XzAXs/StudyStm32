#ifndef __IIC_H__
#define __IIC_H__
#include "stdint.h"
//#define MYGPIOX A
//#if(MYGPIOX==A)
//#define MYGPIO  RCC_APB2Periph_GPIOA
//#elif(MYGPIO==B)
//#define MYGPIO  RCC_APB2Periph_GPIOB
//#elif(MYGPIO==C)
//#define MYGPIO  RCC_APB2Periph_GPIOC
//#elif(MYGPIO==D)
//#define MYGPIO  RCC_APB2Periph_GPIOD
//#endif

#define I2C_NO_Ack 1
#define I2C_Ack   0

#define MYGPIOSCL GPIO_Pin_11
#define MYGPIOSDA GPIO_Pin_10
void I2C_GPIO_Init(void);
void I2C_SDA_SET(void); // SDA = 1
void I2C_SDA_RESET(void); // SDA = 0    
void I2C_SCL_SET(void); // SCL = 1
void I2C_SCL_RESET(void); // SCL = 0
uint8_t I2C_SDA_Read(void); // 读取SDA线状态
void I2C_Start(void);
void I2C_Stop(void);
void I2C_WriteByte(uint8_t byte);
uint8_t I2C_ReadByte(uint8_t ack);
uint8_t I2C_Wait_Ack(void);
int My_SI2C_WriteByte(uint8_t dev_addr, const uint8_t *pdata, uint16_t Size);
int My_SI2C_ReadByte(uint8_t dev_addr, uint8_t *pBuff, uint8_t Size);
#endif // __IIC_H__
