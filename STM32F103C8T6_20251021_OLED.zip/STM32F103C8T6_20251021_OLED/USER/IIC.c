#include "config.h"
/**
 * @file IIC.c
 * @brief IIC模块,软件模拟IIC协议
 * @author XZ
 * @version 1.0
 * @date 2025-09-16
 * @copyright 无版权
 */
/**
 * @brief 初始化IIC接口
 * @details 初始化IIC接口相关设置
 * @return 无返回值
 */
void I2C_GPIO_Init(void)
{
	GPIO_InitTypeDef I2C_GPIOStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	I2C_GPIOStructure.GPIO_Mode  = GPIO_Mode_Out_OD;
	I2C_GPIOStructure.GPIO_Pin   = MYGPIOSCL | MYGPIOSDA;
	I2C_GPIOStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOB, &I2C_GPIOStructure);
	
	I2C_SDA_SET();
	I2C_SCL_SET();
	
}
/**
 * @brief 微妙级延时函数
 * @details 延时指定的微秒数
 * @param us 延时时间，单位为微秒
 * @return 无返回值
 */
void delay_us(uint16_t us)
{
    uint32_t i;
    for(i=0; i<us*8; i++);
}
/**
 * @brief 读取IIC接口上的SDA引脚状态
 * @details 读取IIC接口上的SDA引脚状态
 * @return SDA引脚状态，1表示高电平，0表示低电平
 */
uint8_t I2C_SDA_Read(void)
{
    return GPIO_ReadInputDataBit(GPIOB, MYGPIOSDA);
}
/**
 * @brief 设置IIC接口上的SDA引脚为高电平
 * @details 设置IIC接口上的SDA引脚为高电平
 * @return 无返回值
 */
void I2C_SDA_SET(void)
{
    GPIO_SetBits(GPIOB, MYGPIOSDA);
}
/**
 * @brief 设置IIC接口上的SDA引脚为低电平
 * @details 设置IIC接口上的SDA引脚为低电平
 * @return 无返回值
 */
void I2C_SDA_RESET(void)
{
    GPIO_ResetBits(GPIOB, MYGPIOSDA);
}
/**
 * @brief 设置IIC接口上的SCL引脚为高电平
 * @details 设置IIC接口上的SCL引脚为高电平
 * @return 无返回值
 */
void I2C_SCL_SET(void)
{
    GPIO_SetBits(GPIOB, MYGPIOSCL);
}
/**
 * @brief 设置IIC接口上的SCL引脚为低电平
 * @details 设置IIC接口上的SCL引脚为低电平
 * @return 无返回值
 */
void I2C_SCL_RESET(void)
{
    GPIO_ResetBits(GPIOB, MYGPIOSCL);
}
/**
 * @brief 发送IIC接口上的起始信号
 * @details 发送IIC接口上的起始信号
 * @return 无返回值
 */
static void I2C_Start(void)
{
    //SDA和SCL都为高电平时，SDA从1变为0，产生起始信号
	I2C_SDA_SET();
	I2C_SCL_SET();
	delay_us(1);
	
	I2C_SDA_RESET();
	delay_us(1);
	//SCL拉低，准备发送数据
	I2C_SCL_RESET();
	delay_us(1);
}
/**
 * @brief 发送IIC接口上的停止信号
 * @details 发送IIC接口上的停止信号
 * @return 无返回值
 */
static void I2C_Stop(void)
{
    //SCL为高电平时，SDA从0变为1，产生停止信号
	I2C_SDA_RESET();
	delay_us(1);

	I2C_SCL_RESET();
	delay_us(1);
	
	I2C_SCL_SET();
	delay_us(1);
	
	I2C_SDA_SET();
	delay_us(1);
}

static unsigned char I2C_Wait_Ack(void)
{
	unsigned char Ack;
	//释放SDA总线，等待从机发送ACK信号
	I2C_SCL_RESET();
	delay_us(1);
	
	I2C_SDA_SET();
	delay_us(1);
	
	I2C_SCL_SET();
	delay_us(1);
	
	if(I2C_SDA_Read())
	{
		Ack = I2C_NO_Ack;
	}
	else
	{
		Ack = I2C_Ack;
	}
	//拉低SCL，准备下一个位
	I2C_SCL_RESET();
	delay_us(1);
	
	return Ack;
}

static void I2C_WriteByte(uint8_t I2C_Byte)
{
	uint8_t i = 0;
	
	for(i=0;i<8;i++)
	{
		//拉低SCL，准备发送数据
		I2C_SCL_RESET();
		delay_us(1);
		
		if(I2C_Byte & 0x80)
		{
			I2C_SDA_SET();
		}
		else
		{
			I2C_SDA_RESET();
		}
		
		I2C_Byte <<= 1;
		delay_us(1);
		
		I2C_SCL_SET();
		delay_us(1);
	}
	//多余了，待检查
	I2C_SCL_RESET();
	delay_us(1);
	
}
uint8_t I2C_ReadByte(uint8_t Ack)
{
    uint8_t i = 0;
    uint8_t I2C_Byte = 0;
    
    I2C_SDA_SET(); //释放SDA总线，准备接收数据
    delay_us(1);

    for(i=0;i<8;i++)
    {
        I2C_SCL_RESET();
        delay_us(1);
        
        I2C_SCL_SET();
        delay_us(1);
        
        I2C_Byte <<= 1;
        if(I2C_SDA_Read())
        {
            I2C_Byte |= 0x01;
        }
        //else I2C_Byte |= 0x00; //可省略
    }
    //拉低SCL，准备下一个位
    I2C_SCL_RESET();
    delay_us(1);
    
    // 6. 根据ack参数，决定发送ACK还是NACK
    if (Ack == 0) // 需要继续读取，发送ACK
    {
        I2C_SDA_RESET();
        delay_us(1);
        I2C_SCL_SET();
        delay_us(1); 
    }
    else // 这是最后一个字节，发送NACK
    {
        I2C_SDA_SET();
        delay_us(1);
        I2C_SCL_SET();
        delay_us(1);
    }

    return I2C_Byte;
}
/**
 * @brief 通过IIC接口向指定设备写入数据
 * @details 通过IIC接口向指定设备写入数据
 * @param dev_addr 设备地址
 * @param pdata 待写入的数据指针
 * @param Size 待写入的数据字节数
 * @return 写入成功返回0，寻址失败返回-1，数据写入失败返回-2
 */
int My_SI2C_WriteByte(uint8_t dev_addr, const uint8_t *pdata, uint16_t Size)
{
    I2C_Start();
    I2C_WriteByte(dev_addr << 1);
    if (I2C_Wait_Ack() == I2C_NO_Ack)
    {
        I2C_Stop();
        return -1;
    }
    while(Size--)
    {
        I2C_WriteByte(*pdata);
        if (I2C_Wait_Ack() == I2C_NO_Ack)
        {
            I2C_Stop();
            return -2;
        }
        pdata++;
    }
    I2C_Stop();
    return 0;
}
/**
 * @brief 通过IIC接口从指定设备读取数据
 * @details 通过IIC接口从指定设备读取数据
 * @param dev_addr 设备地址
 * @param pBuff 待读取的数据存放指针
 * @param Size 待读取的数据字节数
 * @return 读取成功返回0，寻址失败返回-1，数据读取失败返回-2
 */
int My_SI2C_ReadByte(uint8_t dev_addr, uint8_t *pBuff, uint8_t Size)
{
    I2C_Start();
    // 发送设备地址+读取指令
    I2C_WriteByte(dev_addr << 1 | 0x01);
    if (I2C_Wait_Ack() == I2C_NO_Ack)
    {
        I2C_Stop();
        return -1;
    }
    while(Size--)
    {
        *pBuff = I2C_ReadByte(Size == 0 ? I2C_NO_Ack : I2C_Ack);
        pBuff++;
    }

    I2C_Stop();
    return 0;
}
